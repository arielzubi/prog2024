package main;

import view.Pantalla;


public class Biblioteca {

    public static void main(String[] args) {
        Pantalla panta = new Pantalla();
        panta.setVisible(true);
    }
    
}
