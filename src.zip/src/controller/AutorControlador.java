package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Autor;
import model.AutorDao;
import view.Pantalla;

public class AutorControlador implements ActionListener, MouseListener, KeyListener {
    private Autor autor;
    private AutorDao autorDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public AutorControlador(Autor autor, AutorDao autorDao, Pantalla panta) {
        this.autor = autor;
        this.autorDao = autorDao;
        this.panta = panta;
        
        //Botón de registrar autor
        this.panta.btn_Agregar_Autor.addActionListener(this);
        //Botón de modificar autor
        this.panta.btn_Modificar_Autor.addActionListener(this);
        //Botón de borrar autor
        this.panta.btn_Borrar_Autor.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_Limpiar_Autor.addActionListener(this);
        
        //Listado de autor
        this.panta.tb_Autor.addMouseListener(this);
              
        listarAutores(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_Agregar_Autor){
            //verifica si el campo nombre está vacío
            if(panta.txt_Nombre_Autor.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo nombre es obligatorio");
            }else{
                //Realiza el agregado
                autor.setNombreAutor(panta.txt_Nombre_Autor.getText());
                if(autorDao.agregarAutor(autor)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutores();
                    JOptionPane.showMessageDialog(null, "Se agregó el autor");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el autor");
                }
            }
        }else if(e.getSource() == panta.btn_Modificar_Autor){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Autor.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                autor.setIdAutor(Integer.parseInt(panta.txt_Id_Autor.getText()));
                autor.setNombreAutor(panta.txt_Nombre_Autor.getText());
                if(autorDao.modificarAutor(autor)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutores();
                    JOptionPane.showMessageDialog(null, "Se modificó el autor");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el autor");
                }
            }
        }else if(e.getSource() == panta.btn_Borrar_Autor){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Autor.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_Id_Autor.getText());
                if(autorDao.borrarAutor(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarAutores();
                    JOptionPane.showMessageDialog(null, "Se eliminó el autor");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el autor");
                }
            }
        }else if(e.getSource() == panta.btn_Limpiar_Autor){
                limpiarTabla();
                limpiarCampos();
                listarAutores();    
                panta.btn_Agregar_Autor.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Autor){
            int row = panta.tb_Autor.rowAtPoint(e.getPoint());
            panta.txt_Id_Autor.setText(panta.tb_Autor.getValueAt(row,0).toString());
            panta.txt_Nombre_Autor.setText(panta.tb_Autor.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_Agregar_Autor.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los autores
    public void listarAutores(){

        panta.cmb_Autor.removeAllItems();

        List<Autor> list = autorDao.listarAutor();
        model = (DefaultTableModel) panta.tb_Autor.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdAutor();
            row[1] = list.get(i).getNombreAutor();
            model.addRow(row);
            panta.cmb_Autor.addItem(list.get(i).getNombreAutor());
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_Id_Autor.setText("");
        panta.txt_Nombre_Autor.setText("");
    }
    
}
