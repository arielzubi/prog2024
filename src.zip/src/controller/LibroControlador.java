package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Libro;
import model.LibroDao;
import view.Pantalla;
import model.AutorDao;
import model.EditorialDao;
import model.GeneroDao;

public class LibroControlador implements ActionListener, MouseListener, KeyListener {
    private Libro libro;
    private LibroDao libroDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public LibroControlador(Libro libro, LibroDao libroDao, Pantalla panta) {
        this.libro = libro;
        this.libroDao = libroDao;
        this.panta = panta;
        
        //Botón de registrar libro
        this.panta.btn_Agregar_Libro.addActionListener(this);
        //Botón de modificar libro
        this.panta.btn_Modificar_Libro.addActionListener(this);
        //Botón de borrar libro
        this.panta.btn_Borrar_Libro.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_Limpiar_Libro.addActionListener(this);
        
        //Listado de libro
        this.panta.tb_Libro.addMouseListener(this);
              
        listarLibros(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_Agregar_Libro){
            //verifica si el campo título está vacío
            if(panta.txt_Titulo_Libro.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo título es obligatorio");
            }else{
                //Realiza el agregado
                AutorDao autorDao = new AutorDao();
                int idAutor = autorDao.buscarIdAutor(panta.cmb_Autor.getSelectedItem().toString());
                EditorialDao editorialDao = new EditorialDao();
                int idEditorial = editorialDao.buscarIdEditorial(panta.cmb_Editorial.getSelectedItem().toString());
                GeneroDao generoDao = new GeneroDao();
                int idGenero = generoDao.buscarIdGenero(panta.cmb_Genero.getSelectedItem().toString());

                libro.setTituloLibro(panta.txt_Titulo_Libro.getText());
                libro.setIdAutor(idAutor);
                libro.setIdEditorial(idEditorial);
                libro.setIdGenero(idGenero);
                
                if(libroDao.agregarLibro(libro)){
                    limpiarTabla();
                    limpiarCampos();
                    listarLibros();
                    JOptionPane.showMessageDialog(null, "Se agregó el libro");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el libro");
                }
            }
        }else if(e.getSource() == panta.btn_Modificar_Libro){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Libro.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                AutorDao autorDao = new AutorDao();
                int idAutor = autorDao.buscarIdAutor(panta.cmb_Autor.getSelectedItem().toString());
                EditorialDao editorialDao = new EditorialDao();
                int idEditorial = editorialDao.buscarIdEditorial(panta.cmb_Editorial.getSelectedItem().toString());
                GeneroDao generoDao = new GeneroDao();
                int idGenero = generoDao.buscarIdGenero(panta.cmb_Genero.getSelectedItem().toString());

                libro.setIdLibro(Integer.parseInt(panta.txt_Id_Libro.getText()));
                libro.setTituloLibro(panta.txt_Titulo_Libro.getText());
                libro.setIdAutor(idAutor);
                libro.setIdEditorial(idEditorial);
                libro.setIdGenero(idGenero);
                if(libroDao.modificarLibro(libro)){
                    limpiarTabla();
                    limpiarCampos();
                    listarLibros();
                    JOptionPane.showMessageDialog(null, "Se modificó el libro");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el libro");
                }
            }
        }else if(e.getSource() == panta.btn_Borrar_Libro){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Libro.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_Id_Libro.getText());
                if(libroDao.borrarLibro(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarLibros();
                    JOptionPane.showMessageDialog(null, "Se eliminó el libro");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el libro");
                }
            }
        }else if(e.getSource() == panta.btn_Limpiar_Libro){
                limpiarTabla();
                limpiarCampos();
                listarLibros();    
                panta.btn_Agregar_Libro.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Libro){
            int row = panta.tb_Libro.rowAtPoint(e.getPoint());
            panta.txt_Id_Libro.setText(panta.tb_Libro.getValueAt(row,0).toString());
            panta.txt_Titulo_Libro.setText(panta.tb_Libro.getValueAt(row,1).toString());

            panta.cmb_Autor.setSelectedItem(panta.tb_Libro.getValueAt(row,2).toString());
            panta.cmb_Editorial.setSelectedItem(panta.tb_Libro.getValueAt(row,3).toString());
            panta.cmb_Genero.setSelectedItem(panta.tb_Libro.getValueAt(row,4).toString());

            //Deshabilitar
            panta.btn_Agregar_Libro.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los autores
    public void listarLibros(){
        List<Libro> list = libroDao.listarLibro();
        model = (DefaultTableModel) panta.tb_Libro.getModel();
        Object[] row = new Object[5];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdLibro();
            row[1] = list.get(i).getTituloLibro();
            row[2] = list.get(i).getNombreAutor();
            row[3] = list.get(i).getNombreEditorial();
            row[4] = list.get(i).getNombreGenero();
            model.addRow(row);
        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_Id_Libro.setText("");
        panta.txt_Titulo_Libro.setText("");
        panta.txt_Id_Autor.setText("");
        panta.txt_Id_Editorial.setText("");
        panta.txt_Id_Genero.setText("");
    }
    
}
