package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Editorial;
import model.EditorialDao;
import view.Pantalla;

public class EditorialControlador implements ActionListener, MouseListener, KeyListener {
    private Editorial editorial;
    private EditorialDao editorialDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public EditorialControlador(Editorial editorial, EditorialDao editorialDao, Pantalla panta) {
        this.editorial = editorial;
        this.editorialDao = editorialDao;
        this.panta = panta;
        
        //Botón de registrar editorial
        this.panta.btn_Agregar_Editorial.addActionListener(this);
        //Botón de modificar editorial
        this.panta.btn_Modificar_Editorial.addActionListener(this);
        //Botón de borrar editorial
        this.panta.btn_Borrar_Editorial.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_Limpiar_Editorial.addActionListener(this);
        
        //Listado de editorial
        this.panta.tb_Editorial.addMouseListener(this);
              
        listarEditoriales(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_Agregar_Editorial){
            //verifica si el campo nombre está vacío
            if(panta.txt_Nombre_Editorial.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo nombre es obligatorio");
            }else{
                //Realiza el agregado
                editorial.setNombreEditorial(panta.txt_Nombre_Editorial.getText());
                if(editorialDao.agregarEditorial(editorial)){
                    limpiarTabla();
                    limpiarCampos();
                    listarEditoriales();
                    JOptionPane.showMessageDialog(null, "Se agregó la editorial");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar la editorial");
                }
            }
        }else if(e.getSource() == panta.btn_Modificar_Editorial){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Editorial.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                editorial.setIdEditorial(Integer.parseInt(panta.txt_Id_Editorial.getText()));
                editorial.setNombreEditorial(panta.txt_Nombre_Editorial.getText());
                if(editorialDao.modificarEditorial(editorial)){
                    limpiarTabla();
                    limpiarCampos();
                    listarEditoriales();
                    JOptionPane.showMessageDialog(null, "Se modificó la editorial");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar la editorial");
                }
            }
        }else if(e.getSource() == panta.btn_Borrar_Editorial){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Editorial.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_Id_Editorial.getText());
                if(editorialDao.borrarEditorial(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarEditoriales();
                    JOptionPane.showMessageDialog(null, "Se eliminó la editorial");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar la editorial");
                }
            }
        }else if(e.getSource() == panta.btn_Limpiar_Editorial){
                limpiarTabla();
                limpiarCampos();
                listarEditoriales();    
                panta.btn_Agregar_Editorial.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Editorial){
            int row = panta.tb_Editorial.rowAtPoint(e.getPoint());
            panta.txt_Id_Editorial.setText(panta.tb_Editorial.getValueAt(row,0).toString());
            panta.txt_Nombre_Editorial.setText(panta.tb_Editorial.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_Agregar_Editorial.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos las editoriales
    public void listarEditoriales(){

        panta.cmb_Editorial.removeAllItems();

        List<Editorial> list = editorialDao.listarEditorial();
        model = (DefaultTableModel) panta.tb_Editorial.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdEditorial();
            row[1] = list.get(i).getNombreEditorial();
            model.addRow(row);
            
            panta.cmb_Editorial.addItem(list.get(i).getNombreEditorial());

        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_Id_Editorial.setText("");
        panta.txt_Nombre_Editorial.setText("");
    }
    
}
