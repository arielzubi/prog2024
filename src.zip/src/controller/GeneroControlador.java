package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Genero;
import model.GeneroDao;
import view.Pantalla;

public class GeneroControlador implements ActionListener, MouseListener, KeyListener {
    private Genero genero;
    private GeneroDao generoDao;
    private Pantalla panta;

    DefaultTableModel model = new DefaultTableModel();

    public GeneroControlador(Genero genero, GeneroDao generoDao, Pantalla panta) {
        this.genero = genero;
        this.generoDao = generoDao;
        this.panta = panta;
        
        //Botón de registrar genero
        this.panta.btn_Agregar_Genero.addActionListener(this);
        //Botón de modificar genero
        this.panta.btn_Modificar_Genero.addActionListener(this);
        //Botón de borrar genero
        this.panta.btn_Borrar_Genero.addActionListener(this);
        //Botón de limpiar
        this.panta.btn_Limpiar_Genero.addActionListener(this);
        
        //Listado de genero
        this.panta.tb_Genero.addMouseListener(this);
              
        listarGeneros(); 
        
    }

    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == panta.btn_Agregar_Genero){
            //verifica si el campo nombre está vacío
            if(panta.txt_Nombre_Genero.getText().equals("")){
                JOptionPane.showMessageDialog(null, "El campo nombre es obligatorio");
            }else{
                //Realiza el agregado
                genero.setNombreGenero(panta.txt_Nombre_Genero.getText());
                if(generoDao.agregarGenero(genero)){
                    limpiarTabla();
                    limpiarCampos();
                    listarGeneros();
                    JOptionPane.showMessageDialog(null, "Se agregó el género");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al agregar el género");
                }
            }
        }else if(e.getSource() == panta.btn_Modificar_Genero){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Genero.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza la modificación
                genero.setIdGenero(Integer.parseInt(panta.txt_Id_Genero.getText()));
                genero.setNombreGenero(panta.txt_Nombre_Genero.getText());
                if(generoDao.modificarGenero(genero)){
                    limpiarTabla();
                    limpiarCampos();
                    listarGeneros();
                    JOptionPane.showMessageDialog(null, "Se modificó el género");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al modificar el género");
                }
            }
        }else if(e.getSource() == panta.btn_Borrar_Genero){
            //verifica si el campo id está vacío
            if(panta.txt_Id_Genero.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe seleccionar un registro desde la tabla");
            }else{
                //Realiza el borrado
                int id = Integer.parseInt(panta.txt_Id_Genero.getText());
                if(generoDao.borrarGenero(id)){
                    limpiarTabla();
                    limpiarCampos();
                    listarGeneros();
                    JOptionPane.showMessageDialog(null, "Se eliminó el género");
                }else{
                    JOptionPane.showMessageDialog(null, "Ha ocurrido un error al eliminar el género");
                }
            }
        }else if(e.getSource() == panta.btn_Limpiar_Genero){
                limpiarTabla();
                limpiarCampos();
                listarGeneros();    
                panta.btn_Agregar_Genero.setEnabled(true);
        }    
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == panta.tb_Genero){
            int row = panta.tb_Genero.rowAtPoint(e.getPoint());
            panta.txt_Id_Genero.setText(panta.tb_Genero.getValueAt(row,0).toString());
            panta.txt_Nombre_Genero.setText(panta.tb_Genero.getValueAt(row,1).toString());
            //Deshabilitar
            panta.btn_Agregar_Genero.setEnabled(false);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    //Listar todos los géneros
    public void listarGeneros(){
        
        panta.cmb_Genero.removeAllItems();

        List<Genero> list = generoDao.listarGenero();
        model = (DefaultTableModel) panta.tb_Genero.getModel();
        Object[] row = new Object[2];
        limpiarTabla();
        for(int i = 0; i < list.size(); i++){
            row[0] = list.get(i).getIdGenero();
            row[1] = list.get(i).getNombreGenero();
            model.addRow(row);
            
            panta.cmb_Genero.addItem(list.get(i).getNombreGenero());

        }
    }


    //Limpiar la tabla
    public void limpiarTabla(){
        for (int i = 0; i < model.getRowCount(); i++){
            model.removeRow(i);
            i = i - 1;
        }
    }
    //Limpiar los campos
    public void limpiarCampos(){
        panta.txt_Id_Genero.setText("");
        panta.txt_Nombre_Genero.setText("");
    }
    
}
