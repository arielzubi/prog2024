package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class GeneroDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public GeneroDao() {
    }
    //Agregar genero
    public boolean agregarGenero(Genero genero){
        String query = "INSERT INTO genero (nombreGenero) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,genero.getNombreGenero());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el género" + e);
            return false;
        }
    }
    
    //Modificar genero
    public boolean modificarGenero(Genero genero){
        String query = "UPDATE genero SET nombreGenero = ? WHERE idGenero = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,genero.getNombreGenero());
            pst.setInt(2, genero.getIdGenero());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el género" + e);
            return false;
        }
    }

    //Borrar genero
    public boolean borrarGenero(int id){
        String query = "DELETE FROM genero WHERE idGenero = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el género" + e);
            return false;
        }
    }

    //Listar genero
    public List listarGenero(){
        List<Genero> list_generos = new ArrayList();
        String query = "SELECT * FROM genero ORDER BY nombregenero ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Genero genero = new Genero();
                genero.setIdGenero(rs.getInt("idgenero"));
                genero.setNombreGenero(rs.getString("nombregenero"));
                list_generos.add(genero);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_generos;
    }    

    //Buscar id de genero
    public int buscarIdGenero(String nombre){
        int id = 0;
        String query = "SELECT idgenero FROM genero WHERE nombregenero = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idgenero");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de genero" + e);
        }
        return id;
    }
    
}
