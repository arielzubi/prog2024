package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class LibroDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public LibroDao() {
    }
    //Agregar libro
    public boolean agregarLibro(Libro libro){
        String query = "INSERT INTO libro (tituloLibro, idAutor, idEditorial, idGenero) VALUES(?,?,?,?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,libro.getTituloLibro());
            pst.setInt(2,libro.getIdAutor());
            pst.setInt(3,libro.getIdEditorial());
            pst.setInt(4,libro.getIdGenero());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el libro" + e);
            return false;
        }
    }
    
    //Modificar libro
    public boolean modificarLibro(Libro libro){
        String query = "UPDATE libro SET tituloLibro = ?, idAutor = ?, idEditorial = ?, idGenero = ? WHERE idLibro = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,libro.getTituloLibro());
            pst.setInt(2, libro.getIdAutor());
            pst.setInt(3, libro.getIdEditorial());
            pst.setInt(4, libro.getIdGenero());
            pst.setInt(5, libro.getIdLibro());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el libro" + e);
            return false;
        }
    }

    //Borrar libro
    public boolean borrarLibro(int id){
        String query = "DELETE FROM libro WHERE idLibro = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el libro" + e);
            return false;
        }
    }

    //Listar libro
    public List listarLibro(){
        List<Libro> list_libros = new ArrayList();
        String query = "SELECT li.*, au.nombreautor, ed.nombreeditorial, ge.nombregenero FROM libro as li inner join autor as au on li.idautor = au.idautor inner join editorial as ed on li.ideditorial = ed.ideditorial inner join genero as ge on li.idgenero = ge.idgenero ORDER BY titulolibro ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Libro libro = new Libro();
                libro.setIdLibro(rs.getInt("idlibro"));
                libro.setTituloLibro(rs.getString("titulolibro"));
                libro.setNombreAutor(rs.getString("nombreAutor"));
                libro.setNombreEditorial(rs.getString("nombreeditorial"));
                libro.setNombreGenero(rs.getString("nombregenero"));
                list_libros.add(libro);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_libros;
    }    
    
}
