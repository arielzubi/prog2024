package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class EditorialDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public EditorialDao() {
    }
    //Agregar editorial
    public boolean agregarEditorial(Editorial editorial){
        String query = "INSERT INTO editorial (nombreEditorial) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,editorial.getNombreEditorial());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar la editorial" + e);
            return false;
        }
    }
    
    //Modificar editorial
    public boolean modificarEditorial(Editorial editorial){
        String query = "UPDATE editorial SET nombreEditorial = ? WHERE idEditorial = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,editorial.getNombreEditorial());
            pst.setInt(2, editorial.getIdEditorial());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar la editorial" + e);
            return false;
        }
    }

    //Borrar editorial
    public boolean borrarEditorial(int id){
        String query = "DELETE FROM editorial WHERE idEditorial = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar la editorial" + e);
            return false;
        }
    }

    //Listar editorial
    public List listarEditorial(){
        List<Editorial> list_editoriales = new ArrayList();
        String query = "SELECT * FROM editorial ORDER BY nombreeditorial ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Editorial editorial = new Editorial();
                editorial.setIdEditorial(rs.getInt("ideditorial"));
                editorial.setNombreEditorial(rs.getString("nombreeditorial"));
                list_editoriales.add(editorial);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_editoriales;
    }    

    //Buscar id de editorial
    public int buscarIdEditorial(String nombre){
        int id = 0;
        String query = "SELECT ideditorial FROM editorial WHERE nombreeditorial = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("ideditorial");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de editorial" + e);
        }
        return id;
    }
    
}
