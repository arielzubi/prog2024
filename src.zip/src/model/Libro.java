package model;

public class Libro {
    private int idLibro;
    private String tituloLibro;
    private int idAutor;
    private int idEditorial;
    private int idGenero;
    
    private String nombreAutor;
    private String nombreEditorial;
    private String nombreGenero;
    
    public Libro() {
    }

    public Libro(int idLibro, String tituloLibro, int idAutor, int idEditorial, int idGenero) {
        this.idLibro = idLibro;
        this.tituloLibro = tituloLibro;
        this.idAutor = idAutor;
        this.idEditorial = idEditorial;
        this.idGenero = idGenero;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public String getTituloLibro() {
        return tituloLibro;
    }

    public void setTituloLibro(String tituloLibro) {
        this.tituloLibro = tituloLibro;
    }

    public int getIdAutor() {
        return idAutor;
    }

    public void setIdAutor(int idAutor) {
        this.idAutor = idAutor;
    }

    public int getIdEditorial() {
        return idEditorial;
    }

    public void setIdEditorial(int idEditorial) {
        this.idEditorial = idEditorial;
    }

    public int getIdGenero() {
        return idGenero;
    }

    public void setIdGenero(int idGenero) {
        this.idGenero = idGenero;
    }

    public String getNombreAutor() {
        return nombreAutor;
    }

    public void setNombreAutor(String nombreAutor) {
        this.nombreAutor = nombreAutor;
    }

    public String getNombreEditorial() {
        return nombreEditorial;
    }

    public void setNombreEditorial(String nombreEditorial) {
        this.nombreEditorial = nombreEditorial;
    }

    public String getNombreGenero() {
        return nombreGenero;
    }

    public void setNombreGenero(String nombreGenero) {
        this.nombreGenero = nombreGenero;
    }
    
}
