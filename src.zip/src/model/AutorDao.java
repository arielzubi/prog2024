package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class AutorDao {
    //Instanciar la conexión
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    public AutorDao() {
    }
    //Agregar autor
    public boolean agregarAutor(Autor autor){
        String query = "INSERT INTO autor (nombreAutor) VALUES(?)";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,autor.getNombreAutor());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al registrar el autor" + e);
            return false;
        }
    }
    
    //Modificar autor
    public boolean modificarAutor(Autor autor){
        String query = "UPDATE autor SET nombreAutor = ? WHERE idAutor = ?";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.setString(1,autor.getNombreAutor());
            pst.setInt(2, autor.getIdAutor());
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al modificar el autor" + e);
            return false;
        }
    }

    //Borrar autor
    public boolean borrarAutor(int id){
        String query = "DELETE FROM autor WHERE idAutor = " + id;
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            pst.execute();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al borrar el autor" + e);
            return false;
        }
    }

    //Listar autor
    public List listarAutor(){
        List<Autor> list_autores = new ArrayList();
        String query = "SELECT * FROM autor ORDER BY nombreautor ASC";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){
                Autor autor = new Autor();
                autor.setIdAutor(rs.getInt("idautor"));
                autor.setNombreAutor(rs.getString("nombreautor"));
                list_autores.add(autor);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }
        return list_autores;
    }    
    
    //Buscar id de autor
    public int buscarIdAutor(String nombre){
        int id = 0;
        String query = "SELECT idautor FROM autor WHERE nombreautor = '" + nombre + "'";
        try {
            con = cn.conectar();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while(rs.next()){            
                id = rs.getInt("idautor");            
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al buscar el id de autor" + e);
        }
        return id;
    }

}
